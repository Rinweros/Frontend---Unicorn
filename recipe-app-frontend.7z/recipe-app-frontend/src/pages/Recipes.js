import React, { useEffect, useState } from 'react';
import { getRecipes } from '../services/api';

const Recipes = () => {
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const response = await getRecipes();
        setRecipes(response);
      } catch (error) {
        console.error('Error fetching recipes:', error);
      }
    };

    fetchRecipes();
  }, []);

  return (
    <div>
      <h1>Recipes</h1>
      {recipes.map((recipe) => (
        <div key={recipe._id}>
          <h2>{recipe.title}</h2>
          <p>{recipe.instructions}</p>
          <p>{recipe.ingredients}</p>
          <p>{recipe.author}</p>
        </div>
      ))}
    </div>
  );
};

export default Recipes;
