import React, { useEffect, useState } from 'react';
import { getProfile } from '../services/api';

const ProfilePage = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const userId = localStorage.user;  // replace with actual user ID
        console.log(userId);
        const response = await getProfile(userId);
        setUser(response);
      } catch (error) {
        console.error('Error fetching user:', error);
      }
    };

    fetchProfile();
  }, []);

  if (!user) {
    return <div>Loading...</div>;
  }
  const myJSON = JSON.stringify(user);
  return (
    <div>
      <h1>Profile Page</h1>
      <p>Username: {user.user.username}</p>
    </div>
  );
};

export default ProfilePage;
