import React, { useState } from 'react';
import { addRecipe } from '../services/api';

const AddRecipe = () => {
  const [title, setTitle] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [instructions, setInstructions] = useState('');
  const [author, setAuthor] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addRecipe({ title, ingredients, instructions, author });
      alert('Recipe added successfully');
    } catch (error) {
      console.error('Error adding recipe:', error);
      alert('Failed to add recipe');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>
      <div>
        <label>Ingredients:</label>
        <textarea
          value={ingredients}
          onChange={(e) => setIngredients(e.target.value)}
        ></textarea>
      </div>
      <div>
        <label>Instructions:</label>
        <textarea
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
        ></textarea>
      </div>
      <div>
        <label>Author:</label>
        <textarea
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        ></textarea>
      </div>
      <button type="submit">Add Recipe</button>
    </form>
  );
};

export default AddRecipe;
