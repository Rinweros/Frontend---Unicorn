import React from 'react';
import UserForm from '../components/UserForm';

function Register() {
  return (
    <div>
      <h2>Register</h2>
      <UserForm />
    </div>
  );
}

export default Register;
