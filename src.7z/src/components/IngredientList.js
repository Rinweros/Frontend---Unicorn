import React, { useEffect, useState } from 'react';
import api from '../services/api';

function IngredientList({ recipeId }) {
  const [ingredients, setIngredients] = useState([]);

  useEffect(() => {
    const fetchIngredients = async () => {
      try {
        const response = await api.get(`/recipes/${recipeId}/ingredients`);
        setIngredients(response.data);
      } catch (error) {
        console.error('Error fetching ingredients:', error);
      }
    };

    if (recipeId) {
      fetchIngredients();
    }
  }, [recipeId]);

  return (
    <div>
      <h2>Ingredients</h2>
      <ul>
        {ingredients.map((ingredient, index) => (
          <li key={index}>{ingredient}</li>
        ))}
      </ul>
    </div>
  );
}

export default IngredientList;
