import React from 'react';
import IngredientList from './IngredientList';

function RecipeDetails({ recipe }) {
  return (
    <div>
      <h1>{recipe.title}</h1>
      <p>{recipe.description}</p>
      <IngredientList recipeId={recipe._id} />
    </div>
  );
}

export default RecipeDetails;
